var express = require('express');
var multer = require('multer');
var router = express.Router();


var storage = multer.diskStorage({
  // destino del fichero
  destination: function (req, file, cb) {
    cb(null, './uploads/')
  },
  // renombrar fichero
  filename: function (req, file, cb) {
    cb(null, file.originalname);
  }
});

var upload = multer({ storage: storage });


/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});


// router.post("/upload", upload.array("uploads[]", 12), function (req, res) {
//   // console.log('files', req.files);
//   //res.send(req.files);
//   console.log(req.body)
//   console.log(req.files)
// });

router.post("/upload", function (req, res) {
  upload(req,res,function(err){
    if(err){
         res.json({error_code:1,err_desc:err});
         return;
    }
     res.json({error_code:0,err_desc:null});
})
});

module.exports = router;
